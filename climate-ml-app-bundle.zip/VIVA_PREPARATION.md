# Viva Preparation

## 1. Project introduction (about 60–90 seconds)

“My project is a modular machine-learning system with three separate regression experiments. The Agriculture module estimates country-year cereal yield using World Bank indicators. The rainfall module uses NOAA daily measurements from Phoenix Airport to estimate next-day rainfall. The Sea Level module uses NOAA Jason-3 satellite data to estimate a sea-level anomaly. Each notebook audits its data, prepares features through a scikit-learn pipeline, compares Linear Regression with Random Forest, evaluates a chronological holdout, and saves the fitted pipeline. An integration script loads those saved models and prints one example prediction from each module. The results have important limits: the rainfall model is weak and is worse than predicting zero on MAE, rainfall is not flood prediction, and the sea-level score mainly reflects a short time trend. The models are educational demonstrations, not operational climate forecasts or causal scientific models.”

## 2. Architecture and workflow

1. Source records live in `data/raw/`.
2. Each notebook audits its own data and writes a prepared CSV to `data/`.
3. Each notebook splits data chronologically, fits preprocessing only on training data, compares Linear Regression and Random Forest, and records validation/test metrics.
4. The selected fitted pipeline and its target/features/metrics are stored as a bundle in `models/`.
5. `integration.py` validates the saved bundle and CSV, preserves feature order, selects the first complete row, and calls `predict` without refitting.

## 3. Complete workflow in simple terms

- **Features (`X`)** are the information given to a model. The **target (`y`)** is the value it tries to estimate.
- A **regression problem** predicts a number such as yield, rainfall amount, or a sea-level anomaly.
- The **training set** is used to learn the relationship. A **validation set** helps choose between the two models. The later **test set** gives a final check on data that was not used for selection.
- **Preprocessing** turns raw columns into forms a model can use. `StandardScaler` rescales numeric values; `OneHotEncoder` converts categories such as country or month into numeric indicator columns.
- `ColumnTransformer` applies the correct transformation to each column group. `Pipeline` keeps preprocessing and the estimator together, so training and inference use the same learned transformations.
- **Data leakage** occurs when information unavailable at prediction time or learned from the test data is allowed into training. These notebooks fit scalers/encoders within training pipelines and use earlier time periods for fitting.
- **Linear Regression** is a simple baseline that fits a weighted straight-line relationship. **Random Forest** averages predictions from many decision trees; it can model nonlinear patterns but cannot extrapolate a smooth time trend well.
- **RMSE** penalizes large errors more; **MAE** is the average absolute error in the target's units; **R²** compares against a mean-prediction baseline for the evaluated split. None proves causation.
- **Overfitting** means a model matches training data patterns that do not generalize to later/unseen observations.
- **Reproducibility** means repeating the workflow with the same source data, seed, and compatible package versions produces the same prepared data and metrics.

## 4. Model and preprocessing questions

**Why compare Linear Regression and Random Forest?**  
Linear Regression is an understandable baseline. Random Forest can learn nonlinear splits and interactions. The comparison tests whether added complexity improves held-out performance; Random Forest is not assumed to win.

**Why scale numeric features if Random Forest does not need it?**  
The tree model is largely insensitive to scale. Scaling is included for a consistent documented pipeline; it is needed more for models such as Linear Regression when numeric scales differ.

**Why encode categories?**  
Most scikit-learn estimators require numeric input. One-hot encoding represents categories such as country or month without pretending that their text labels have numeric order.

**Why save a whole pipeline rather than just an estimator?**  
The pipeline includes the fitted scaler, encoder, column mapping, and estimator. That ensures inference repeats the transformations learned during training.

**Why are the feature names stored in the bundle?**  
The integration script uses the exact expected columns and order. It fails clearly if the prepared dataset no longer matches the model contract.

**Does the integration script retrain the models?**  
No. It loads the fitted joblib bundles and calls `predict`. Training happens in the notebooks.

## 5. Dataset-specific questions

### Agriculture

**Why can country matter?**  
Countries differ in climate, agricultural systems, reporting, technology, crop mix, and many other factors. Country may act as a proxy for several unmeasured differences.

**Why is the yield target cereal-wide rather than crop-specific?**  
The available verified source is an aggregate cereal-yield indicator. It does not provide the exact expected crop/country dataset. The limitation is documented instead of inventing a crop feature.

**What does the precipitation feature mean?**  
It is the World Bank's long-term average precipitation in mm/year for a country. The same value is repeated for that country's years, so it does not measure annual weather variation.

**Why investigate the high yield values?**  
The maximum is 36,761.9 kg/ha and 71 rows exceed 10,000 kg/ha. These may reflect unusual crop mixes, small harvested areas, or source/reporting effects. I retained them because the source alone did not justify deleting them; they can influence metrics and feature importance.

**Does R² = 0.7757 prove the model learned how climate causes yield?**  
No. It describes performance relative to a mean predictor on a later country-year split. Country, year, and same-year fertilizer can be proxies; association and prediction do not establish causation.

**What did Random Forest feature importance show?**  
The largest values were fertilizer use (about 35.5%), the UAE category (17.5%), year (14.4%), average precipitation (11.8%), and St. Vincent and the Grenadines (11.1%). This shows which inputs the fitted model relied on in this dataset, not which factors caused yield.

### Flood-related rainfall

**Does this model predict floods?**  
No. Its target is next-day rainfall at Phoenix Airport. Flood occurrence also depends on soil saturation, river levels, drainage, terrain, and upstream rainfall. The dataset has no flood-occurrence target.

**Why use previous-day data?**  
At a next-day prediction time, previous-day precipitation and temperatures are available. Using the target day's temperatures could leak information not available at the forecast time.

**Why not use `RainTomorrow`?**  
This module uses NOAA GHCN-Daily, which has no `RainTomorrow` feature. In a different dataset, a field that directly encodes future rain can leak the target when predicting future rainfall, so it should be excluded unless the prediction setup explicitly makes it available.

**How good is the rainfall model?**  
It is weak. The selected Linear Regression has test RMSE 2.205 mm, MAE 0.868 mm, and R² 0.048. It is slightly better than the all-zero predictor on RMSE, but much worse on MAE; it also produced 63 negative predictions. Random Forest has lower MAE than Linear Regression but remains worse than the all-zero MAE reference. The model is an academic comparison, not a useful rainfall-warning system.

**Why are many targets zero?**  
The Phoenix daily series has about 90% zero-rainfall targets. This makes a no-rain reference important and makes typical absolute error different from performance on the less frequent wet days.

### Sea level

**Is the sea-level dataset synthetic?**  
No. The project uses NOAA Laboratory for Satellite Altimetry's observational Jason-3 satellite series. It has 329 observations from 2016–2025 and measures an anomaly in mm.

**Why can R² be relatively high?**  
The target rises over the observed time span and Year is a direct time coordinate. Linear Regression can fit that trend. This does not prove the model learned the physical causes of sea-level change.

**Does the result generalize to the future?**  
Not established. The final test includes only 38 later observations from the same satellite series, and the record is short. Long-range forecasting and new satellite missions were not tested.

## 6. Actual results to explain

| Module | Selected model | Final test RMSE | Final test MAE | Final test R² |
|---|---|---:|---:|---:|
| Agriculture, cereal yield | Random Forest | 1,611.38 kg/ha | 657.88 kg/ha | 0.7757 |
| Next-day rainfall | Linear Regression | 2.205 mm | 0.868 mm | 0.0480 |
| Jason-3 sea-level anomaly | Linear Regression | 2.717 mm | 2.228 mm | 0.7353 |

Integration example: 1,169.474 kg/ha, 0.769 mm, and 46.914 mm anomaly for the first complete rows. These are different targets and are not a combined score.

## 7. Difficult follow-up questions

**Why did you use a chronological split instead of a random split?**  
Rows close in time can be related. A random split could train on a later year and test on an earlier neighboring record. A chronological split better checks later observations, though countries/station/mission remain represented in training.

**Is fertilizer use a leakage feature?**  
It is not the target itself or a direct arithmetic component of the yield indicator, but it is measured in the same year and may be unavailable when making an advance forecast. This module is retrospective country-year estimation, not a future-season forecasting system.

**Why not delete the extremes or clip negative rainfall predictions?**  
There was not enough evidence to discard or alter source data silently. The notebooks report unusual values and predictions. Clipping would change the evaluated model behavior; a future nonnegative method should be trained and evaluated explicitly.

**Why does the rainfall model not beat the all-zero MAE?**  
Most days are dry. The regression models issue nonzero estimates that may help some large-rainfall errors (RMSE) but create errors on many dry days. This is why model results must be compared with simple references and multiple metrics.

**Why does Random Forest do poorly on the sea-level test?**  
The test period is later than training. A tree-based model generally predicts within ranges represented by its training leaves and does not extend a linear time trend smoothly. Linear Regression extrapolates the trend more effectively here.

**Are feature importances causal explanations?**  
No. They describe how a fitted model used its inputs under this dataset and split. Correlated/proxy features can appear important without causing the target.

**Can the model predict a country or month it did not see?**  
The encoder is configured to ignore unknown categories, but this does not guarantee good predictions for unseen entities. Evaluation did not test held-out countries/stations/missions.

## 8. Claims to avoid

- “This system predicts floods.” It predicts rainfall at one station; there is no flood target.
- “The Agriculture R² proves climate drives crop yield.” The model is predictive, uses proxies, and lacks annual local weather/crop-specific inputs.
- “The sea-level model proves climate change causes this trend.” It fits a time trend on a short satellite anomaly series.
- “All three predictions are comparable.” They use different targets and units.
- “The rainfall model is accurate/useful.” Its MAE loses to a simple all-zero reference and some predictions are negative.
- “High R² means scientific validity or causation.” It does not.
- “The models generalize to all countries, stations, or future scenarios.” That was not evaluated.
