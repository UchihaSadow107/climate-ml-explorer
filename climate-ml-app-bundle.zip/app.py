from pathlib import Path

import numpy as np
import pandas as pd
import streamlit as st

from integration import load_bundle


ROOT = Path(__file__).resolve().parent
MODEL_DIR = ROOT / "models"
DATA_DIR = ROOT / "data"

MODULES = {
    "Agriculture": {
        "model_file": "agriculture_model.pkl",
        "data_file": "agriculture_real.csv",
        "target_label": "Cereal yield",
        "unit": "kg/ha",
        "description": "Estimate country-year aggregate cereal yield.",
    },
    "Next-day rainfall": {
        "model_file": "flood_model.pkl",
        "data_file": "flood_real.csv",
        "target_label": "Next-day rainfall",
        "unit": "mm",
        "description": "Estimate next-day precipitation for the Phoenix Airport station.",
    },
    "Sea-level anomaly": {
        "model_file": "sea_level_model.pkl",
        "data_file": "sea_level.csv",
        "target_label": "Jason-3 sea-level anomaly",
        "unit": "mm anomaly",
        "description": "Estimate a satellite-observed sea-level anomaly.",
    },
}


@st.cache_resource
def load_model_bundle(model_file):
    return load_bundle(MODEL_DIR / model_file)


@st.cache_data
def load_dataset(data_file):
    return pd.read_csv(DATA_DIR / data_file)


def predict(bundle, values):
    features = bundle["features"]
    missing_features = [feature for feature in features if feature not in values]
    if missing_features:
        raise ValueError(f"Missing model features: {missing_features}")

    input_row = pd.DataFrame([{feature: values[feature] for feature in features}])
    numeric_values = input_row[bundle["numeric_cols"]].to_numpy(dtype=float)
    if not np.isfinite(numeric_values).all():
        raise ValueError("All numeric inputs must be finite numbers.")

    result = np.asarray(bundle["model"].predict(input_row))
    if result.shape != (1,) or not np.isfinite(result[0]):
        raise ValueError("The model did not return one finite numeric prediction.")
    return float(result[0])


def show_agriculture_form(dataset, bundle):
    with st.form("agriculture_form"):
        country = st.selectbox(
            "Country",
            sorted(dataset["country"].dropna().unique().tolist()),
        )
        left, right = st.columns(2)
        year = left.number_input(
            "Year",
            min_value=int(dataset["year"].min()),
            max_value=int(dataset["year"].max()),
            value=int(dataset["year"].max()),
        )
        precipitation = right.number_input(
            "Average precipitation (mm/year)",
            min_value=0.0,
            value=float(dataset["average_precipitation_mm_per_year"].median()),
            step=10.0,
        )
        fertilizer = left.number_input(
            "Fertilizer use (kg/ha)",
            min_value=0.0,
            value=float(dataset["fertilizer_kg_per_ha"].median()),
            step=1.0,
        )
        submitted = st.form_submit_button("Estimate cereal yield")

    if submitted:
        return predict(
            bundle,
            {
                "country": country,
                "year": year,
                "average_precipitation_mm_per_year": precipitation,
                "fertilizer_kg_per_ha": fertilizer,
            },
        )
    return None


def show_rainfall_form(dataset, bundle):
    with st.form("rainfall_form"):
        month = st.selectbox(
            "Target month",
            [
                "January",
                "February",
                "March",
                "April",
                "May",
                "June",
                "July",
                "August",
                "September",
                "October",
                "November",
                "December",
            ],
        )
        left, right = st.columns(2)
        previous_rainfall = left.number_input(
            "Previous-day rainfall (mm)",
            min_value=0.0,
            value=float(dataset["Previous_Rainfall_mm"].median()),
            step=0.1,
        )
        previous_tmax = right.number_input(
            "Previous-day maximum temperature (°C)",
            value=float(dataset["Previous_Tmax_C"].median()),
            step=0.1,
        )
        previous_tmin = left.number_input(
            "Previous-day minimum temperature (°C)",
            value=float(dataset["Previous_Tmin_C"].median()),
            step=0.1,
        )
        submitted = st.form_submit_button("Estimate next-day rainfall")

    if submitted:
        return predict(
            bundle,
            {
                "Previous_Rainfall_mm": previous_rainfall,
                "Previous_Tmax_C": previous_tmax,
                "Previous_Tmin_C": previous_tmin,
                "Month": month,
            },
        )
    return None


def show_sea_level_form(dataset, bundle):
    months = [
        ("Jan", "January"),
        ("Feb", "February"),
        ("Mar", "March"),
        ("Apr", "April"),
        ("May", "May"),
        ("Jun", "June"),
        ("Jul", "July"),
        ("Aug", "August"),
        ("Sep", "September"),
        ("Oct", "October"),
        ("Nov", "November"),
        ("Dec", "December"),
    ]

    with st.form("sea_level_form"):
        year = st.number_input(
            "Year (decimal)",
            min_value=float(dataset["Year"].min()),
            max_value=float(dataset["Year"].max()),
            value=float(dataset["Year"].max()),
            step=0.01,
            format="%.4f",
        )
        month = st.selectbox("Month", [label for _, label in months])
        submitted = st.form_submit_button("Estimate sea-level anomaly")

    if submitted:
        return predict(
            bundle,
            {
                "Year": year,
                "Month": next(value for value, label in months if label == month),
            },
        )
    return None


st.set_page_config(
    page_title="Climate ML Explorer",
    page_icon="🌍",
    layout="centered",
)
st.title("Climate ML Explorer")
st.write(
    "Explore three independent predictions from fitted machine-learning models. "
    "Each module has different inputs and units; results are not combined."
)

with st.sidebar:
    st.header("About this project")
    st.write("Educational demonstrations using public World Bank and NOAA datasets.")
    st.caption(
        "Predictions are not operational forecasts, warnings, or scientific causal conclusions."
    )

tabs = st.tabs(list(MODULES))
form_functions = [
    show_agriculture_form,
    show_rainfall_form,
    show_sea_level_form,
]

for tab, (module_name, module), render_form in zip(
    tabs, MODULES.items(), form_functions
):
    with tab:
        st.subheader(module_name)
        st.write(module["description"])
        if module_name == "Agriculture":
            st.info(
                "Precipitation is a long-term country average, not the selected year's weather. "
                "The model was trained on observations from 1990–2022."
            )
        elif module_name == "Next-day rainfall":
            st.warning(
                "This estimates rainfall at one Phoenix station; it does not predict floods. "
                "The fitted model performs worse than an all-zero reference on test MAE, "
                "and its estimates are intentionally not clipped."
            )
        else:
            st.info(
                "This is a Jason-3 sea-level anomaly, not absolute sea level. "
                "Enter a decimal year within the observed 2016–2025 range. "
                "The model fits a short time trend; it is not a reliable long-range forecast."
            )

        try:
            bundle = load_model_bundle(module["model_file"])
            dataset = load_dataset(module["data_file"])
            st.caption(f"Model: {bundle['model_type']} · Target: {bundle['target']}")
            prediction = render_form(dataset, bundle)
        except (FileNotFoundError, OSError, KeyError, TypeError, ValueError) as error:
            st.error(f"Unable to produce a prediction: {error}")
        else:
            if prediction is not None:
                st.metric(
                    module["target_label"],
                    f"{prediction:,.3f} {module['unit']}",
                )
                if module_name == "Next-day rainfall" and prediction < 0:
                    st.warning(
                        "The regression model returned a negative rainfall estimate. "
                        "It is shown without clipping."
                    )

st.divider()
st.caption(
    "For methodology, evaluation results, sources, and limitations, see the project README."
)
