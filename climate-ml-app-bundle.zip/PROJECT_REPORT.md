# Project Report: Modular Multi-Domain Climate Impact Prediction System

## Abstract

This project implements three independent, CPU-friendly regression experiments using classical machine-learning methods. The Agriculture module estimates country-year aggregate cereal yield from World Bank indicators. The rainfall module estimates next-calendar-day precipitation at one NOAA weather station. The sea-level module estimates a NOAA Jason-3 satellite sea-level anomaly from time information. Each notebook audits and prepares its data, compares Linear Regression with Random Forest, evaluates a chronological holdout, and saves a fitted preprocessing/model pipeline. The rainfall results show very limited practical skill and do not constitute flood prediction. The sea-level result fits a short time trend and does not demonstrate causal climate physics. All predictions are domain-specific and are not combined into a single climate-impact score.

## 1. Introduction and problem statement

Climate-related measurements include different targets, units, sources, and time scales. This project demonstrates how regression can be applied separately to agricultural yield, rainfall, and sea-level observations while preserving the limitations of each dataset. The system is intended for learning, not operational forecasting or policy decisions.

## 2. Objectives

- Audit each source dataset before modeling.
- Build reproducible Linear Regression and Random Forest pipelines.
- Use chronological validation and final test periods where the records are time-dependent.
- Calculate RMSE, MAE, and R² using the correct target units.
- Save fitted preprocessing-plus-model bundles for inference.
- Integrate all three saved models in one Python script.
- Distinguish observational measurements, proxies, and model predictions honestly.

## 3. Dataset description and quality

### 3.1 Agriculture

The raw WDI API records cover 1990–2023 for three indicators: cereal yield (`AG.YLD.CREL.KG`), average precipitation (`AG.LND.PRCP.MM`), and fertilizer consumption (`AG.CON.FERT.ZS`). The notebook excludes regional aggregates and joins complete records by ISO-3 country code and year. The resulting `data/agriculture_real.csv` has 5,419 unique country-year rows across 175 countries from 1990 through 2022, with no missing model values after the documented intersection join.

The target is cereal yield in kg/ha, not crop-specific yield. Average precipitation is defined as a long-term average in mm/year and is repeated across years for a country; it cannot represent year-to-year rainfall variation. The data does not include verified annual temperature or pesticide-use features. The target ranges from 0.1 to 36,761.9 kg/ha, including 71 records above 10,000 kg/ha. These extremes were retained rather than deleted without evidence.

### 3.2 Rainfall

The rainfall module uses NOAA NCEI GHCN-Daily station `USW00023183`, identified in NOAA station metadata as Phoenix Airport, Arizona. The `.dly` source contains fixed-width daily observations. Values are converted from tenths of their measurement units to mm for precipitation and °C for maximum/minimum temperature. Missing sentinels and nonblank quality flags are excluded. NOAA's `P` measurement flag means “missing presumed zero” and is excluded; trace precipitation is retained at its recorded numeric zero.

The target is next-calendar-day precipitation. Features are prior-day precipitation, TMAX, TMIN, and the known target month. A complete calendar is created before shifting so that an observation is not treated as the previous day if dates are actually separated by a gap. The prepared data has 29,363 examples from 1933-07-13 through 2026-10-22. About 90% of targets are zero. This is a single-station dataset and the target is rainfall, not flood occurrence.

### 3.3 Sea level

The sea-level module uses NOAA Laboratory for Satellite Altimetry's global mean sea-level anomaly CSV and selects only the Jason-3 column. Other mission columns are not merged because they represent different satellite series. The selected dataset has 329 observations from fractional year 2016.1228 through 2025.0197, with no duplicate timestamps or missing model values. The target is a satellite-derived anomaly in mm, not absolute sea level. Month is derived as a coarse category from fractional year.

## 4. Methodology

Each notebook:

1. Loads its source data using project-relative paths.
2. Audits the shape, types, missing values, duplicates, target distribution, numeric summaries, and relevant relationships.
3. Separates `X` and `y`, verifies the target is not an input, and derives numeric/categorical column lists.
4. Uses a `ColumnTransformer` and `Pipeline`, with `StandardScaler` for numeric features and `OneHotEncoder(handle_unknown="ignore")` for categorical features.
5. Trains Linear Regression as the baseline and a CPU-friendly Random Forest Regressor.
6. Selects the estimator using validation RMSE; reports both models on the later final test period.
7. Saves the selected fitted pipeline and its feature/metric metadata with `joblib`.

The chronological periods are Agriculture: train through 2014, validation 2015–2018, test 2019–2022; Rainfall: train through 2014, validation 2015–2018, test 2019 onward; Sea Level: train before 2022, validation 2022–2023, test 2024 onward. The same countries, station, or mission can occur in more than one period, so results do not establish generalization to new entities.

## 5. System architecture and implementation

- `data/raw/` contains source records downloaded from the World Bank API and NOAA.
- `notebooks/agriculture_prediction.ipynb`, `notebooks/flood_rainfall_prediction.ipynb`, and `notebooks/sea_level_prediction.ipynb` audit, prepare, train, evaluate, and save each module.
- `data/` contains the notebook-generated model-ready CSVs.
- `models/` contains fitted bundles with the required keys: `model`, `target`, `features`, `numeric_cols`, `categorical_cols`, `model_type`, and `metrics`.
- `integration.py` loads the prepared CSVs and bundles, validates the bundle/data contracts, selects the first row with complete features in the stored feature order, and calls the fitted pipeline without retraining.

## 6. Results and discussion

The following are final chronological holdout metrics from the clean rerun:

| Module / target | Model | RMSE | MAE | R² |
|---|---|---:|---:|---:|
| Cereal yield (kg/ha) | Linear Regression | 1,773.99 | 806.36 | 0.7281 |
| Cereal yield (kg/ha) | Random Forest Regressor (selected) | 1,611.38 | 657.88 | 0.7757 |
| Next-day rainfall (mm) | Linear Regression (selected) | 2.205 | 0.868 | 0.0480 |
| Next-day rainfall (mm) | Random Forest Regressor | 2.275 | 0.799 | −0.0140 |
| Next-day rainfall (mm) | Always predict 0 mm | 2.294 | 0.393 | −0.0303 |
| Next-day rainfall (mm) | Training-mean reference | 2.265 | 0.858 | −0.0049 |
| Jason-3 sea-level anomaly (mm) | Linear Regression (selected) | 2.717 | 2.228 | 0.7353 |
| Jason-3 sea-level anomaly (mm) | Random Forest Regressor | 7.127 | 5.979 | −0.8212 |

RMSE and MAE are in the target units. RMSE penalizes larger errors more strongly; MAE is the average absolute error; R² compares performance with a mean-prediction baseline on the specified test sample.

The Agriculture model is better than Linear Regression on the final split, but extreme target values and same-country observations across time can influence the score. The Random Forest's largest importances were fertilizer use (35.5%), the UAE category (17.5%), year (14.4%), average precipitation (11.8%), and the St. Vincent and the Grenadines category (11.1%). Country-specific categories and same-year inputs therefore contribute materially to the fit; importance or correlation is not evidence of causation.

For Rainfall, Linear Regression won validation RMSE but produced 63 negative estimates on the final test; these were not clipped. Both fitted models have higher MAE than the all-zero reference, which reflects the highly zero-heavy target and shows that the selected model is not useful for typical absolute error on this holdout. It should not be used for operational rainfall warning or flood prediction.

For Sea Level, Linear Regression captures a time trend more effectively than Random Forest, which does not extrapolate the trend well. The test has only 38 observations and the record spans less than a decade. The R² score is not evidence of climate causation, physical understanding, or reliable long-term forecasts.

The integration script generated one example from each saved model: 1,169.474 kg/ha cereal yield, 0.769 mm next-day rainfall, and 46.914 mm Jason-3 anomaly. These are predictions for the first complete input rows and are not directly comparable.

## 7. Limitations

- The three modules use unrelated datasets, targets, time ranges, and units; the system does not calculate a unified climate impact.
- Agriculture uses aggregate cereal yields and a repeated long-term precipitation average; it lacks crop-specific and annual climate predictors.
- The rainfall model is station-specific, highly zero-inflated, weak against a simple reference on MAE, and may predict negative rainfall.
- The sea-level dataset is a short satellite anomaly series; time features can capture its trend without representing causal physical processes.
- Chronological holdouts test later records of represented entities, not unseen countries or locations.
- The datasets' licenses/redistribution terms should be checked before external redistribution.

## 8. Conclusion and future work

The project provides a reproducible educational workflow for data auditing, preprocessing pipelines, regression comparison, evaluation, model saving, and integration. The Agriculture and Sea Level models fit their evaluated data better than their respective alternatives, but their scores do not establish causal or broad real-world validity. The rainfall experiment demonstrates why a model must be compared against simple baselines and why rainfall is not synonymous with flooding.

Future work could add annual local weather and crop-specific observations for Agriculture, broaden rainfall coverage to multiple stations and additional weather predictors, validate on separate locations, investigate nonnegative/probabilistic rainfall approaches, and evaluate sea-level forecasting on longer independently held-out data.

## 9. References

1. World Bank, World Development Indicators API, cereal yield: https://api.worldbank.org/v2/indicator/AG.YLD.CREL.KG?format=json
2. World Bank, World Development Indicators API, average precipitation: https://api.worldbank.org/v2/indicator/AG.LND.PRCP.MM?format=json
3. World Bank, World Development Indicators API, fertilizer consumption: https://api.worldbank.org/v2/indicator/AG.CON.FERT.ZS?format=json
4. NOAA NCEI, Global Historical Climatology Network Daily: https://www.ncei.noaa.gov/products/land-based-station/global-historical-climatology-network-daily
5. NOAA GHCN-Daily readme and format/flags: https://www.ncei.noaa.gov/pub/data/ghcn/daily/readme.txt
6. Menne et al. (2012), “An Overview of the Global Historical Climatology Network-Daily Database,” *Journal of Atmospheric and Oceanic Technology*, DOI: https://doi.org/10.1175/JTECH-D-11-00103.1
7. NOAA NCEI, GHCN-Daily dataset DOI: https://doi.org/10.7289/V5D21VHZ
8. NOAA Laboratory for Satellite Altimetry, global sea-level time series: https://www.star.nesdis.noaa.gov/socd/lsa/SeaLevelRise/LSA_SLR_timeseries_global.php
