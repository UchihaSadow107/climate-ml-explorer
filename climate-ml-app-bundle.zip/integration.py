from pathlib import Path
import sys

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline


PROJECT_ROOT = Path(__file__).resolve().parent
MODEL_DIR = PROJECT_ROOT / "models"
DATA_DIR = PROJECT_ROOT / "data"

REQUIRED_BUNDLE_KEYS = {
    "model",
    "target",
    "features",
    "numeric_cols",
    "categorical_cols",
    "model_type",
    "metrics",
}

MODULES = [
    {
        "name": "AGRICULTURE",
        "model_file": "agriculture_model.pkl",
        "dataset_file": "agriculture_real.csv",
        "prediction_label": "Predicted cereal yield",
        "unit": "kg/ha",
    },
    {
        "name": "FLOOD-RELATED RAINFALL ANALYSIS",
        "model_file": "flood_model.pkl",
        "dataset_file": "flood_real.csv",
        "prediction_label": "Predicted next-day rainfall",
        "unit": "mm",
    },
    {
        "name": "SEA-LEVEL CHANGE",
        "model_file": "sea_level_model.pkl",
        "dataset_file": "sea_level.csv",
        "prediction_label": "Predicted sea-level anomaly",
        "unit": "mm anomaly",
    },
]


def load_bundle(model_path):
    if not model_path.is_file():
        raise FileNotFoundError(
            f"Model bundle not found: {model_path}. Run the corresponding notebook first."
        )

    bundle = joblib.load(model_path)
    if not isinstance(bundle, dict):
        raise ValueError(f"Model bundle must be a dictionary: {model_path}")

    missing_keys = REQUIRED_BUNDLE_KEYS - bundle.keys()
    if missing_keys:
        raise ValueError(
            f"Model bundle {model_path.name} is missing required keys: "
            f"{sorted(missing_keys)}"
        )

    features = bundle["features"]
    numeric_cols = bundle["numeric_cols"]
    categorical_cols = bundle["categorical_cols"]
    if not isinstance(features, list) or not all(
        isinstance(feature, str) for feature in features
    ):
        raise ValueError(f"Bundle {model_path.name} has an invalid features list.")
    if len(features) != len(set(features)):
        raise ValueError(f"Bundle {model_path.name} has duplicate feature names.")
    if bundle["target"] in features:
        raise ValueError(
            f"Target {bundle['target']!r} is incorrectly included in model features."
        )
    if not isinstance(numeric_cols, list) or not isinstance(categorical_cols, list):
        raise ValueError(
            f"Bundle {model_path.name} must store numeric_cols and categorical_cols as lists."
        )
    if len(numeric_cols) != len(set(numeric_cols)) or len(categorical_cols) != len(
        set(categorical_cols)
    ):
        raise ValueError(f"Bundle {model_path.name} has duplicate preprocessing columns.")
    if set(numeric_cols).intersection(categorical_cols):
        raise ValueError(
            f"Bundle {model_path.name} assigns a feature to both preprocessing groups."
        )
    if set(numeric_cols).union(categorical_cols) != set(features):
        raise ValueError(
            f"Bundle {model_path.name} feature and preprocessing column lists do not match."
        )

    model = bundle["model"]
    if not isinstance(model, Pipeline):
        raise ValueError(f"Bundle {model_path.name} does not contain a fitted Pipeline.")
    preprocessor = model.named_steps.get("preprocessor")
    if not isinstance(preprocessor, ColumnTransformer):
        raise ValueError(
            f"Bundle {model_path.name} pipeline has no ColumnTransformer named 'preprocessor'."
        )

    configured_columns = {
        name: columns for name, transformer, columns in preprocessor.transformers
    }
    if configured_columns.get("numeric") != numeric_cols:
        raise ValueError(
            f"Bundle {model_path.name} numeric_cols do not match its fitted pipeline."
        )
    if configured_columns.get("categorical") != categorical_cols:
        raise ValueError(
            f"Bundle {model_path.name} categorical_cols do not match its fitted pipeline."
        )
    return bundle


def load_input_row(dataset_path, bundle):
    if not dataset_path.is_file():
        raise FileNotFoundError(
            f"Prepared dataset not found: {dataset_path}. Run its training notebook first."
        )

    dataset = pd.read_csv(dataset_path)
    if dataset.empty:
        raise ValueError(f"Prepared dataset is empty: {dataset_path}")

    features = bundle["features"]
    missing_columns = [feature for feature in features if feature not in dataset.columns]
    if missing_columns:
        raise ValueError(
            f"Dataset {dataset_path.name} is missing required model features: "
            f"{missing_columns}"
        )

    valid_rows = dataset.dropna(subset=features)
    if valid_rows.empty:
        raise ValueError(
            f"Dataset {dataset_path.name} has no rows with all required model features."
        )

    input_row = valid_rows.iloc[[0]][features]
    numeric_cols = bundle["numeric_cols"]
    try:
        numeric_values = input_row[numeric_cols].to_numpy(dtype=float)
    except (TypeError, ValueError) as error:
        raise ValueError(
            f"Dataset {dataset_path.name} contains nonnumeric values in numeric features."
        ) from error
    if not np.isfinite(numeric_values).all():
        raise ValueError(
            f"Dataset {dataset_path.name} contains non-finite numeric model features."
        )
    return input_row


def predict_module(module):
    model_path = MODEL_DIR / module["model_file"]
    dataset_path = DATA_DIR / module["dataset_file"]
    bundle = load_bundle(model_path)
    input_row = load_input_row(dataset_path, bundle)

    prediction = np.asarray(bundle["model"].predict(input_row))
    if prediction.shape != (1,):
        raise ValueError(
            f"Model {model_path.name} returned prediction shape {prediction.shape}; expected (1,)."
        )
    if not np.issubdtype(prediction.dtype, np.number) or not np.isfinite(prediction[0]):
        raise ValueError(f"Model {model_path.name} returned a non-finite numeric prediction.")

    return bundle, float(prediction[0])


def main():
    print("=" * 58)
    print("MODULAR MULTI-DOMAIN CLIMATE IMPACT PREDICTION SYSTEM")
    print("=" * 58)
    failures = []

    for number, module in enumerate(MODULES, start=1):
        print(f"\n{number}. {module['name']}")
        try:
            bundle, prediction = predict_module(module)
        except (
            FileNotFoundError,
            KeyError,
            OSError,
            TypeError,
            ValueError,
        ) as error:
            message = f"{module['name']} failed: {error}"
            failures.append(message)
            print(f"ERROR: {message}", file=sys.stderr)
            continue

        print(f"Target: {bundle['target']}")
        print(f"Model: {bundle['model_type']}")
        print(f"{module['prediction_label']}: {prediction:.3f} {module['unit']}")
        if module["name"] == "FLOOD-RELATED RAINFALL ANALYSIS":
            print("Note: this is rainfall estimation, not a flood prediction.")
            if prediction < 0:
                print(
                    "Warning: the fitted regression produced a negative rainfall estimate; "
                    "it is reported without clipping."
                )
        elif module["name"] == "SEA-LEVEL CHANGE":
            print("Note: this is a satellite sea-level anomaly, not absolute sea level.")

    print("\n" + "=" * 58)
    if failures:
        print(f"{len(failures)} module(s) failed; see the errors above.")
        raise SystemExit(1)

    print("All three modules executed.")
    print("These outputs use different targets and units and do not form a combined score.")
    print("=" * 58)


if __name__ == "__main__":
    main()
