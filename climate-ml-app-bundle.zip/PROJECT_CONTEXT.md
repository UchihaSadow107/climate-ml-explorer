# Project Context

## Current state

The project contains three completed, CPU-friendly regression modules, their prepared datasets and fitted model bundles, and a shared `integration.py` script. It was built in checkpoints from an initially empty workspace. The raw data files needed to rerun the notebooks are under `data/raw/`.

## Data contracts

| Module | Prepared CSV | Target | Model features | Selected estimator |
|---|---|---|---|---|
| Agriculture | `data/agriculture_real.csv` | `cereal_yield_kg_per_ha` | `country`, `year`, `average_precipitation_mm_per_year`, `fertilizer_kg_per_ha` | Random Forest Regressor |
| Rainfall | `data/flood_real.csv` | `Rainfall` | `Previous_Rainfall_mm`, `Previous_Tmax_C`, `Previous_Tmin_C`, `Month` | Linear Regression |
| Sea Level | `data/sea_level.csv` | `Sea_Level_mm` | `Year`, `Month` | Linear Regression |

The required bundle keys are `model`, `target`, `features`, `numeric_cols`, `categorical_cols`, `model_type`, and `metrics`. Each `model` is a fitted scikit-learn preprocessing-plus-estimator pipeline.

## Sources and caveats

- Agriculture source files are World Bank WDI API records for cereal yield, average precipitation, and fertilizer consumption. The prepared join has 5,419 country-year rows for 175 countries, 1990–2022. The precipitation feature is a long-term country average; it is not year-specific rainfall. The target is aggregate cereal yield, not individual crop yield.
- Rainfall uses NOAA NCEI GHCN-Daily station `USW00023183` (Phoenix Airport, Arizona). The prepared data predicts the next calendar day's rainfall from previous-day observations. It is not a flood target. The selected model is weak and performs worse than an all-zero reference on MAE; 63 of its final test predictions are negative.
- Sea Level uses NOAA Laboratory for Satellite Altimetry's Jason-3 mission column. It has 329 observations from 2016–2025 and measures a sea-level anomaly in mm, not absolute sea level.

## Final holdout metrics

| Module | Selected model | RMSE | MAE | R² | Holdout |
|---|---|---:|---:|---:|---|
| Agriculture | Random Forest Regressor | 1,611.382 kg/ha | 657.875 kg/ha | 0.775694 | 2019–2022 |
| Rainfall | Linear Regression | 2.205 mm | 0.868 mm | 0.047979 | 2019 onward |
| Sea Level | Linear Regression | 2.717 mm anomaly | 2.228 mm anomaly | 0.735301 | 2024 onward |

The rainfall model's all-zero reference has RMSE 2.294 mm, MAE 0.393 mm, and R² −0.0303. Do not present the fitted rainfall model as operationally useful or as flood prediction.

## Run order

1. Install packages from `requirements.txt`.
2. Run `notebooks/agriculture_prediction.ipynb`.
3. Run `notebooks/flood_rainfall_prediction.ipynb`.
4. Run `notebooks/sea_level_prediction.ipynb`.
5. Run `python integration.py` from the project root.

The final clean run reproduced all three saved metric dictionaries and prepared dataset hashes. The integration predictions matched direct calls to the saved pipelines.
