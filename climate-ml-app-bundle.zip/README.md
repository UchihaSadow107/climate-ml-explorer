# Modular Multi-Domain Climate Impact Prediction System

This CPU-friendly project compares classical regression models across three climate-related datasets. It contains one notebook per domain, fitted preprocessing/model pipelines, and an integration script that prints one example prediction from each saved model.

The modules are separate experiments, not components of a single climate-impact score:

1. **Agriculture** estimates country-year cereal yield.
2. **Flood-related rainfall analysis** estimates next-day rainfall at one weather station. It does not predict floods.
3. **Sea-level change** estimates a NOAA Jason-3 satellite sea-level anomaly. It does not predict absolute sea level.

## Project structure

```text
AI project/
├── data/
│   ├── raw/                         # downloaded source records
│   ├── agriculture_real.csv         # WDI country-year join
│   ├── flood_real.csv               # NOAA station next-day rows
│   └── sea_level.csv                # NOAA Jason-3 observations
├── models/
│   ├── agriculture_model.pkl
│   ├── flood_model.pkl
│   └── sea_level_model.pkl
├── notebooks/
│   ├── agriculture_prediction.ipynb
│   ├── flood_rainfall_prediction.ipynb
│   └── sea_level_prediction.ipynb
├── integration.py
├── app.py
├── requirements.txt
├── .gitignore
├── PROJECT_CONTEXT.md
├── PROJECT_REPORT.md
└── VIVA_PREPARATION.md
```

The notebooks create the prepared CSV files and fitted model bundles from the files under `data/raw/`. Run them before using `integration.py`.

## Run the interactive web app locally

Install dependencies from `requirements.txt`, then start Streamlit from the project folder:

```bat
python -m streamlit run app.py
```

The app provides separate forms for agriculture, next-day rainfall, and sea-level anomaly. It loads the existing fitted model bundles; it does not retrain them. Results should be treated as educational demonstrations, not operational forecasts.

## Publish with Streamlit Community Cloud

1. Push this project to a GitHub repository that you are comfortable making public. Include `app.py`, `requirements.txt`, `integration.py`, the `data/` files, and the `models/` bundles.
2. Sign in to Streamlit Community Cloud using the GitHub account with access to that repository.
3. Create an app from the repository, select `app.py` as the main file, and deploy.
4. Streamlit Community Cloud will provide a public `*.streamlit.app` URL when deployment succeeds.

This project currently has no configured GitHub remote or deployment credentials, so a public URL must be generated from the hosting account after the repository is published.

## Dataset sources and preparation

| Module | Source and target | Preparation and important limits |
|---|---|---|
| Agriculture | World Bank World Development Indicators (WDI): cereal yield (`AG.YLD.CREL.KG`) in kg/ha. The indicator metadata attributes the cereal-yield series to FAO. | The notebook joins cereal yield, fertilizer consumption (`AG.CON.FERT.ZS`), and average precipitation (`AG.LND.PRCP.MM`) by country and year, excluding regional aggregates and country-years without all three values. The result has 5,419 rows for 175 countries, 1990–2022. Precipitation is a long-term country average repeated over years, not that year's rainfall. This dataset contains aggregate cereals, not crop-specific yield; verified annual temperature and pesticide inputs were not available in the selected WDI data. |
| Rainfall | NOAA NCEI Global Historical Climatology Network Daily (GHCN-Daily), station `USW00023183` (Phoenix Airport, Arizona). Target: next-calendar-day precipitation in mm. | Fixed-width daily values are converted from tenths of their units. Missing sentinels and failed quality flags are excluded. NOAA's `P` (“missing presumed zero”) precipitation measurements are excluded; trace values are retained as recorded zero. Rows require valid prior-day precipitation/TMAX/TMIN and next-day precipitation. The prepared data has 29,363 examples from 1933–2026 and about 90% zero-rainfall targets. It represents one station only. |
| Sea level | NOAA Laboratory for Satellite Altimetry global sea-level time series, Jason-3 mission column. Target: sea-level anomaly in mm. | Only Jason-3 values are used to avoid mixing separate satellite mission columns. The prepared series has 329 observations from 2016–2025. The NOAA target is a satellite-derived anomaly, not absolute sea level; its short span limits generalization. |

The selected World Bank API responses and source datasets are stored in [`data/raw/`](data/raw/). Source metadata and data terms can change; verify the current terms and requested attribution before redistributing the data. NOAA's altimetry CSV requests the acknowledgment “Altimetry data are provided by NOAA Laboratory for Satellite Altimetry.”

## Method

Each notebook:

1. Loads and audits its source data, including dimensions, missing values, duplicates, types, target summaries, and relevant plots.
2. Defines input features separately from the target.
3. Splits chronologically to reduce leakage from nearby observations.
4. Uses a scikit-learn `Pipeline` with a `ColumnTransformer`, `StandardScaler` for numeric features, and `OneHotEncoder(handle_unknown="ignore")` for categorical features.
5. Compares Linear Regression with a CPU-friendly Random Forest Regressor.
6. Selects the model using validation RMSE, reports RMSE/MAE/R² on a later final holdout, and saves the fitted pipeline in a dictionary bundle.

The validation and final-test periods are:

- Agriculture: validation 2015–2018; final test 2019–2022.
- Rainfall: validation 2015–2018; final test 2019 onward.
- Sea level: validation 2022–2023; final test 2024 onward.

The same countries/station/mission can appear in earlier and later periods. These are chronological evaluations for later observations within the represented series, not evaluations on unseen countries, stations, or satellite missions.

## Final holdout results

All values below were regenerated during the final clean run. RMSE and MAE use each module's target units. R² is relative to the mean-prediction baseline on that holdout; it does not prove causation or scientific validity.

| Module and target | Model/reference | RMSE | MAE | R² |
|---|---|---:|---:|---:|
| Agriculture — cereal yield (kg/ha) | Linear Regression | 1,773.99 | 806.36 | 0.7281 |
| Agriculture — cereal yield (kg/ha) | Random Forest Regressor (selected) | 1,611.38 | 657.88 | 0.7757 |
| Rainfall — next-day rainfall (mm) | Linear Regression (selected) | 2.205 | 0.868 | 0.0480 |
| Rainfall — next-day rainfall (mm) | Random Forest Regressor | 2.275 | 0.799 | −0.0140 |
| Rainfall — next-day rainfall (mm) | Always predict 0 mm | 2.294 | 0.393 | −0.0303 |
| Rainfall — next-day rainfall (mm) | Training-mean reference | 2.265 | 0.858 | −0.0049 |
| Sea level — Jason-3 anomaly (mm) | Linear Regression (selected) | 2.717 | 2.228 | 0.7353 |
| Sea level — Jason-3 anomaly (mm) | Random Forest Regressor | 7.127 | 5.979 | −0.8212 |

### How to interpret these results

- **Agriculture:** the selected Random Forest performs better than the baseline on the later-country-year holdout. The target has unusual extremes (71 records exceed 10,000 kg/ha, with a maximum of 36,761.9 kg/ha). Its largest feature importances were fertilizer use (35.5%), the UAE country category (17.5%), year (14.4%), average precipitation (11.8%), and the St. Vincent and the Grenadines category (11.1%). This suggests country and input proxies influence the fit; importance is not causation.
- **Rainfall:** the fitted models provide little skill. Although Linear Regression was selected by validation RMSE, it has higher final-test MAE than predicting zero rainfall every day and makes 63 negative rainfall estimates on the test set. Predictions are not clipped. This is an educational model comparison, not a useful operational rainfall or flood-risk system.
- **Sea level:** Linear Regression captures a trend in a short Jason-3 time series; the Random Forest does not extrapolate the trend well. The R² value is not evidence of physical understanding, causal climate attribution, or reliable long-range forecasting.

## Setup on Windows

Use Python 3.12 or newer. The project was tested in this environment with Python 3.14.5, pandas 3.1.0, NumPy 2.5.4, scikit-learn 1.9.1, Matplotlib 3.11.2, and joblib 1.6.0.

From **Command Prompt** in the project folder:

```bat
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

In **PowerShell**, activate with:

```powershell
.\.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, use Command Prompt or run the Python executable inside `.venv` directly.

## Run the notebooks and integration

1. Open this folder in VS Code and install/enable the Python and Jupyter extensions.
2. Open each notebook under `notebooks/`, select the `.venv` Python kernel, and run all cells from top to bottom in this order:
   1. `agriculture_prediction.ipynb`
   2. `flood_rainfall_prediction.ipynb`
   3. `sea_level_prediction.ipynb`
3. Confirm that each notebook creates its prepared CSV in `data/` and fitted bundle in `models/`.
4. From the project root, run:

```bat
python integration.py
```

The integration script loads only prepared CSVs and fitted pipelines; it does not fit or retrain models. It chooses the first complete row for each bundle's exact feature list and reports clear errors for missing files, columns, empty data, or invalid model inputs. The three predictions have different targets and units and must not be combined into one score.

## Limitations and possible improvements

- The modules use different data sources, temporal spans, and targets, so they are not a jointly validated climate-impact system.
- The Agriculture precipitation feature is a static country-level long-term average; the module lacks crop-specific and annual temperature/weather measurements.
- The rainfall data covers one Phoenix station and is highly zero-inflated. The selected regression model can predict negative rainfall; the workflow deliberately reports rather than clips those outputs.
- The Sea Level dataset uses only 329 Jason-3 anomalies. The time trend and derived month are not causal climate predictors.
- Chronological splits do not establish performance in new countries, locations, or future regimes.
- None of the modules predicts flood occurrence, severity, or probability.
- Future work could use broader observational coverage, stronger group/time evaluation, additional physical predictors, probabilistic or nonnegative methods where appropriate, and explicit external validation.

For the actual workflow and results, see [`PROJECT_REPORT.md`](PROJECT_REPORT.md) and [`VIVA_PREPARATION.md`](VIVA_PREPARATION.md).
